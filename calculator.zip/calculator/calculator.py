from tkinter import Tk, Entry, Label, END, StringVar


def press_key(char):
    current = display_var.get()
    if current == "Error":
        display_var.set(char)
    else:
        display_var.set(current + char)


def clear_display():
    display_var.set("")


def calculate():
    try:
        expression = display_var.get()
        expression = expression.replace("×", "*").replace("÷", "/")
        result = eval(expression)

        if isinstance(result, float) and result.is_integer():
            result = int(result)

        display_var.set(str(result))
    except Exception:
        display_var.set("Error")


root = Tk()
root.title("Calculator")
root.geometry("300x400")
root.resizable(False, False)
root.configure(bg="#eaeaea")

root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
root.grid_columnconfigure(3, weight=1)

root.grid_rowconfigure(0, weight=2)
for i in range(1, 6):
    root.grid_rowconfigure(i, weight=1)

display_var = StringVar()
display = Entry(
    root,
    textvariable=display_var,
    font=("Arial", 24),
    justify="right",
    bd=0,
    insertwidth=4,
    bg="#eaeaea",
    fg="#000000",
)
display.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=10, pady=10)

buttons = [
    ("C", 1, 0),
    ("÷", 1, 3),
    ("7", 2, 0),
    ("8", 2, 1),
    ("9", 2, 2),
    ("×", 2, 3),
    ("4", 3, 0),
    ("5", 3, 1),
    ("6", 3, 2),
    ("-", 3, 3),
    ("1", 4, 0),
    ("2", 4, 1),
    ("3", 4, 2),
    ("+", 4, 3),
    ("0", 5, 0),
    (".", 5, 1),
    ("=", 5, 2),
]

for text, row, col in buttons:
    if text == "C":
        bg_color = "#ffb347"
    elif text in ("÷", "×", "-", "+", "="):
        bg_color = "#b3e5fc"
    else:
        bg_color = "#ffffff"

    colspan = 2 if text in ("0", "=") else 1

    btn = Label(
        root,
        text=text,
        font=("Arial", 18),
        bd=1,
        relief="solid",
        bg=bg_color,
        fg="#000000",
        anchor="center",
    )

    if text == "C":
        btn.bind("<Button-1>", lambda e: clear_display())
    elif text == "=":
        btn.bind("<Button-1>", lambda e: calculate())
    else:
        btn.bind("<Button-1>", lambda e, t=text: press_key(t))

    btn.grid(
        row=row, column=col, columnspan=colspan, sticky="nsew", padx=3, pady=3
    )

root.mainloop()